import streamlit as st
import pandas as pd
import numpy as np
import joblib
import plotly.express as px
import plotly.figure_factory as ff
from sklearn.datasets import load_iris

# Page setup
st.set_page_config(page_title=" Iris Classifier", layout="wide")
st.title("🌸 Iris Flower Classifier")
st.markdown("Predict the Iris species or explore the dataset visually!")

# Load model
@st.cache_resource
def load_model():
    return joblib.load("iris_model.pkl")

model = load_model()

# Load dataset
iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df["target"] = iris.target
species_map = {0: "Setosa", 1: "Versicolor", 2: "Virginica"}
df["species"] = df["target"].map(species_map)

# Sidebar: Mode selection
mode = st.sidebar.radio("Select Mode", ["Prediction", "Data Exploration"])


# PREDICTION MODE

if mode == "Prediction":
    st.subheader("Enter Flower Measurements")
    st.markdown("Adjust the sliders to set the measurements for a single flower:")
    st.markdown("Hover over sliders to see measurement ranges. ✅")

    col1, col2 = st.columns(2)

    sepal_length = col1.slider("Sepal Length (cm)", 4.0, 8.0, 5.0, help="Length of the sepal in cm")
    sepal_width = col2.slider("Sepal Width (cm)", 2.0, 4.5, 3.0, help="Width of the sepal in cm")
    petal_length = col1.slider("Petal Length (cm)", 1.0, 7.0, 1.5, help="Length of the petal in cm")
    petal_width = col2.slider("Petal Width (cm)", 0.1, 2.5, 0.2, help="Width of the petal in cm")

    input_data = pd.DataFrame({
        "sepal length (cm)": [sepal_length],
        "sepal width (cm)": [sepal_width],
        "petal length (cm)": [petal_length],
        "petal width (cm)": [petal_width]
    })

    st.subheader("Your Input")
    st.table(input_data)

    # Prediction
    pred = model.predict(input_data)[0]
    pred_proba = model.predict_proba(input_data)[0]
    pred_species = species_map[pred]
    confidence = float(pred_proba[pred])

    # Colored card display
    with st.container():
        if confidence >= 0.75:
            st.success(f"🌟 Predicted species: **{pred_species}** (Confidence: {confidence:.2f})")
        elif confidence >= 0.45:
            st.info(f"ℹ️ Predicted species: **{pred_species}** (Confidence: {confidence:.2f})")
        else:
            st.warning(f"⚠️ Low-confidence prediction: **{pred_species}** (Confidence: {confidence:.2f})")

    # Pie chart for probabilities
    proba_df = pd.DataFrame({
        "Species": list(species_map.values()), 
        "Probability": list(pred_proba)
    })
    fig_pie = px.pie(proba_df, names="Species", values="Probability",
                     title="Prediction Confidence")
    st.plotly_chart(fig_pie, use_container_width=True)

# DATA EXPLORATION MODE
else:
    st.subheader("Explore the Iris Dataset")

    # Show raw data
    if st.checkbox("Show Raw Dataset"):
        st.dataframe(df)

    # Histogram
    st.markdown("### Histogram of Features")
    feature_hist = st.selectbox("Select feature for histogram", iris.feature_names)
    bins = st.slider("Number of bins", 5, 50, 15)
    fig_hist = px.histogram(df, x=feature_hist, color="species", nbins=bins,
                            title=f"Histogram of {feature_hist}")
    st.plotly_chart(fig_hist, use_container_width=True)

    # Scatter Matrix
    st.markdown("### Pairwise Feature Scatter Matrix")
    fig_scatter = px.scatter_matrix(df, dimensions=iris.feature_names, color="species",
                                    hover_data=["species"], title="Scatter Matrix")
    st.plotly_chart(fig_scatter, use_container_width=True)

    