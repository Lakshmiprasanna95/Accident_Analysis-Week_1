# Dataset and Model Preparation 

import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import joblib

# Step 1: Loading the Iris dataset
iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.Series(iris.target, name='target')

print("First 5 rows of the dataset:")
print(X.head())
print(y.head())

# Step 2: Split dataset into train and test
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train a basic ML model (e.g., Logistic Regression or Random Forest) for classification.
model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)

# Evaluating the model
y_pred = model.predict(X_test)
print("Test Accuracy:", accuracy_score(y_test, y_pred))

# Save the trained model to a file using joblib or pickle
joblib.dump(model, 'iris_model.pkl')
print("Model saved successfully as 'iris_model.pkl'!")
